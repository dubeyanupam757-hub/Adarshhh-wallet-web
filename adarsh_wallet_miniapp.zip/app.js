(() => {
  const $ = id => document.getElementById(id);
  const tg = API.getTelegram();
  if (tg) { tg.ready(); tg.expand(); try { tg.setHeaderColor("#081225"); tg.setBackgroundColor("#081225"); } catch {} }

  const user = API.getUser();
  const uid = API.getUserId();
  const fullName = user ? [user.first_name, user.last_name].filter(Boolean).join(" ") : "Telegram User";
  const username = user?.username ? "@" + user.username : "Username not set";
  let balance = null;
  let method = "upi";
  let pendingWithdraw = null;

  const money = value => {
    const n = Number(value);
    return Number.isFinite(n) ? "₹" + n.toFixed(2) : "₹—";
  };
  const setMessage = (id, text, type = "") => {
    const el = $(id); el.textContent = text; el.className = "message" + (type ? " " + type : "");
  };
  const showModal = id => $(id).classList.add("show");
  const hideModal = id => $(id).classList.remove("show");
  const escapeHTML = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));

  function fillProfile() {
    const first = (fullName || "U").trim().charAt(0).toUpperCase();
    ["avatar","accountAvatar"].forEach(id => $(id).textContent = first);
    $("homeName").textContent = fullName;
    $("homeUsername").textContent = username;
    $("homeUserId").textContent = "User ID: " + (uid || "Open inside Telegram");
    $("accountName").textContent = fullName;
    $("accountUsername").textContent = username;
    $("accountId").textContent = uid || "Unavailable";
  }

  function navigate(name) {
    document.querySelectorAll(".screen").forEach(s => s.classList.toggle("active", s.id === name));
    document.querySelectorAll(".nav button").forEach(b => b.classList.toggle("active", b.dataset.go === name));
    if (name === "transactions") loadTransactions();
    if (name === "withdrawals") loadWithdrawals();
    if (name === "account") updateBalanceLabels();
    if (name === "withdraw") updateBalanceLabels();
    if (name === "pay") updateBalanceLabels();
    window.scrollTo({top:0,behavior:"smooth"});
  }
  document.querySelectorAll("[data-go]").forEach(b => b.addEventListener("click", () => navigate(b.dataset.go)));

  function updateBalanceLabels() {
    const text = money(balance);
    ["homeBalance","accountBalance","withdrawBalance","payBalance"].forEach(id => $(id).textContent = text);
  }

  async function loadBalance() {
    if (!uid) {
      $("connectionState").textContent = "Open in Telegram";
      updateBalanceLabels();
      return;
    }
    try {
      const result = await API.getBalance(uid);
      if (result.ok && result.balance !== undefined) {
        balance = Number(result.balance);
        updateBalanceLabels();
        $("connectionState").textContent = "Wallet Connected";
      } else {
        $("connectionState").textContent = "API Not Ready";
      }
    } catch (err) {
      $("connectionState").textContent = "API Not Connected";
      console.warn("Balance API:", err);
    }
  }

  function renderRecords(containerId, records, emptyText) {
    const el = $(containerId);
    if (!Array.isArray(records) || records.length === 0) {
      el.innerHTML = `<div class="empty">${escapeHTML(emptyText)}</div>`;
      return;
    }
    el.innerHTML = records.map(item => {
      const title = escapeHTML(item.title || item.type || item.description || "Wallet transaction");
      const date = escapeHTML(item.date || item.created_at || "");
      const amount = Number(item.amount);
      const amountText = Number.isFinite(amount) ? money(amount) : "—";
      const positive = item.direction === "credit" || item.type === "credit" || amount > 0;
      return `<div class="list-item"><div><div class="list-title">${title}</div><div class="list-sub">${date}</div></div><div class="list-amount ${positive ? "positive" : "negative"}">${amountText}</div></div>`;
    }).join("");
  }

  async function loadTransactions() {
    try {
      const r = await API.getTransactions();
      renderRecords("transactionsList", r.transactions || r.data || [], "No transactions found.");
      renderRecords("recentList", (r.transactions || r.data || []).slice(0,3), "No recent activity.");
    } catch (e) { renderRecords("transactionsList", [], "Transactions will appear when the bot API is connected."); }
  }
  async function loadWithdrawals() {
    try {
      const r = await API.getWithdrawHistory();
      renderRecords("withdrawalsList", r.withdrawals || r.data || [], "No withdrawal requests found.");
    } catch (e) { renderRecords("withdrawalsList", [], "Withdrawal history will appear after API connection."); }
  }

  document.querySelectorAll(".tab").forEach(tab => tab.addEventListener("click", () => {
    method = tab.dataset.method;
    document.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t === tab));
    $("receiverLabel").textContent = method === "upi" ? "UPI ID" : "Payzy Number";
    $("receiver").placeholder = method === "upi" ? "name@upi" : "Enter Payzy registered number";
  }));

  $("withdrawBtn").addEventListener("click", () => {
    const to = $("receiver").value.trim();
    const amount = Number($("withdrawAmount").value);
    if (!to) return setMessage("withdrawMessage", "Please enter your payout details.", "error");
    if (!Number.isFinite(amount) || amount <= 0) return setMessage("withdrawMessage", "Enter a valid amount.", "error");
    if (balance !== null && amount > balance) return setMessage("withdrawMessage", "Insufficient balance.", "error");
    pendingWithdraw = {to, amount, method};
    $("reviewDetails").textContent = `${money(amount)} to ${to} via ${method === "upi" ? "UPI" : "Payzy Wallet"}`;
    setMessage("reviewMessage", "");
    showModal("reviewModal");
  });

  $("cancelReview").addEventListener("click", () => hideModal("reviewModal"));
  $("confirmWithdraw").addEventListener("click", async () => {
    if (!pendingWithdraw) return;
    const btn = $("confirmWithdraw"); btn.disabled = true; btn.textContent = "Submitting…";
    try {
      const r = await API.doAction("withdraw", pendingWithdraw);
      if (!r.ok) throw new Error(r.error || "Withdrawal request failed.");
      if (r.new_balance !== undefined) balance = Number(r.new_balance);
      updateBalanceLabels();
      hideModal("reviewModal"); showModal("successModal");
      $("successText").textContent = r.message || "Your withdrawal request has been submitted for admin approval.";
      $("receiver").value = ""; $("withdrawAmount").value = "";
      setMessage("withdrawMessage", "");
    } catch (e) { setMessage("reviewMessage", e.message || "Unable to submit request.", "error"); }
    finally { btn.disabled = false; btn.textContent = "Confirm & Submit"; }
  });
  $("closeSuccess").addEventListener("click", () => { hideModal("successModal"); pendingWithdraw = null; loadBalance(); });

  $("payBtn").addEventListener("click", async () => {
    const to = $("payTo").value.trim(), amount = Number($("payAmount").value);
    if (!to) return setMessage("payMessage", "Enter receiver User ID or username.", "error");
    if (!Number.isFinite(amount) || amount <= 0) return setMessage("payMessage", "Enter a valid amount.", "error");
    if (balance !== null && amount > balance) return setMessage("payMessage", "Insufficient balance.", "error");
    const btn = $("payBtn"); btn.disabled = true; btn.textContent = "Processing…";
    try {
      const r = await API.doAction("pay", {to, amount});
      if (!r.ok) throw new Error(r.error || "Payment failed.");
      if (r.new_balance !== undefined) balance = Number(r.new_balance);
      updateBalanceLabels(); setMessage("payMessage", r.message || "Payment completed.", "success");
      $("payTo").value = ""; $("payAmount").value = "";
    } catch (e) { setMessage("payMessage", e.message || "Unable to process payment.", "error"); }
    finally { btn.disabled = false; btn.textContent = "Pay Now"; }
  });

  $("giftBtn").addEventListener("click", async () => {
    const code = $("giftCode").value.trim();
    if (!code) return setMessage("giftMessage", "Enter a gift code.", "error");
    const btn = $("giftBtn"); btn.disabled = true; btn.textContent = "Checking…";
    try {
      const r = await API.doAction("gift", {code});
      if (!r.ok) throw new Error(r.error || "Invalid or expired gift code.");
      if (r.new_balance !== undefined) balance = Number(r.new_balance);
      updateBalanceLabels(); setMessage("giftMessage", r.message || "Gift code redeemed successfully.", "success");
      $("giftCode").value = "";
    } catch (e) { setMessage("giftMessage", e.message || "Unable to redeem code.", "error"); }
    finally { btn.disabled = false; btn.textContent = "Redeem Code"; }
  });

  $("supportBtn").addEventListener("click", () => {
    const url = "https://t.me/" + (window.BOT_CONFIG?.botUsername || "AdarshhhWallet_bot");
    if (tg?.openTelegramLink) tg.openTelegramLink(url); else window.open(url, "_blank");
  });

  fillProfile();
  loadBalance();
  loadTransactions();
})();
