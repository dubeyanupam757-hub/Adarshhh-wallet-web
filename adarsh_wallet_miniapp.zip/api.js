// Frontend API adapter. Backend webhook endpoints must be implemented in TBC.
const API = {
  getTelegram() {
    return window.Telegram?.WebApp || null;
  },
  getUser() {
    const tg = this.getTelegram();
    return tg?.initDataUnsafe?.user || null;
  },
  getUserId() {
    return this.getUser()?.id ? String(this.getUser().id) : "";
  },
  getUserName() {
    const u = this.getUser();
    return u?.username || u?.first_name || "User";
  },
  async call(command, params = {}, method = "GET") {
    const tg = this.getTelegram();
    const initData = tg?.initData || "";
    const base = window.BOT_CONFIG?.webhookBase;
    if (!base) throw new Error("Webhook configuration missing");
    const url = new URL(`${base}/${command}`);
    const options = {
      method,
      headers: {
        "Content-Type": "application/json",
        "X-Telegram-Init-Data": initData
      }
    };
    if (method === "GET") {
      Object.entries(params).forEach(([k, v]) => {
        if (v !== undefined && v !== null) url.searchParams.set(k, String(v));
      });
    } else {
      options.body = JSON.stringify(params);
    }
    const response = await fetch(url.toString(), options);
    let result;
    try { result = await response.json(); }
    catch { throw new Error("Invalid server response"); }
    if (!response.ok) throw new Error(result.error || `Request failed (${response.status})`);
    return result;
  },
  getBalance(uid = this.getUserId()) {
    return this.call("webhook_balance", { uid });
  },
  getTransactions(uid = this.getUserId(), limit = 20, offset = 0) {
    return this.call("webhook_transactions", { uid, limit, offset });
  },
  getWithdrawHistory(uid = this.getUserId(), limit = 20, offset = 0) {
    return this.call("webhook_withdraw_history", { uid, limit, offset });
  },
  getGiftHistory(uid = this.getUserId()) {
    return this.call("webhook_gift_history", { uid });
  },
  doAction(action, payload = {}) {
    return this.call("webhook_action", { action, ...payload }, "POST");
  }
};
